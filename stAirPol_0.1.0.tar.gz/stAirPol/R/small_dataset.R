#' mini_dataset
#'
#' A dataset which contains 5 days of PM10 in Munich.
#' That dataset is only used for purposes.
#'
#'
#' @docType data
#'
#' @usage data(mini_dataset)
#'
#' @keywords datasets
#'
#'
#' @examples
#' data(mini_dataset)
"mini_dataset"
